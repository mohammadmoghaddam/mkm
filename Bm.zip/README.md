# Tabchi

TG-CLI based broadcasting bot!

## Install
```bash
chmod 777 install.sh
./install.sh
```
## Create a bot!
```
root@iTeam:~# python3 creator.py
Enter Tabchi ID (1,2,3,4,5,...) : 1
Enter Full Sudo ID : 122774063
Done!
New Tabchi Created...
ID : 1
Full Sudo : 122774063
Run : ./tabchi-1.sh
```
Enter id of tabchi in "ID" part (it can be anything but should be unique)

Enter your telegram Id in "Full Sudo ID" part

Enjoy Your New Bot!
## Run
Use `./tabchi-ID.sh` to run your bot normaly or use `screen ./tabchi-ID.sh` for auto launch mode (put tabchi-id in ID part)

## Help and more...
Send `/help` to [@TabChiRobot](https://telegram.me/TabChiRobot) in telegram
## Developers

 * [BugFather (Amir_h)](https://telegram.me/BugFather)
 * [Base64 (Amin)](https://telegram.me/Base64)

### Powered by [iTeam](https://telegram.me/iTeam_IR)
